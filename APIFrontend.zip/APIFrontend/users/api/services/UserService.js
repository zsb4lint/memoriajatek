const { BadRequestError, NotFoundError } = require("../errors");

class UserService
{
    constructor(db)
    {
        this.userRepository = require("../repositories")(db).userRepository;
    }

    async getUsers()
    {
        return await this.userRepository.getUsers();
    }

    async getUser(userID)
    {
        if(!userID) throw new BadRequestError("Missing user identification from payload");

        const user = await this.userRepository.getUser(userID);

        if(!user) throw new NotFoundError("Can not found user with this user identification", 
        {
            data: userID
        });

        return user;
    }

    async createUser(userData)
    {
        if(!userData) throw new BadRequestError("Missing user data from payload", 
        {
            data: userData,
        });

        if(!userData.name) throw new BadRequestError("Missing username from payload",
        {
            data: userData,
        });

        if(!userData.password) throw new BadRequestError("Missing password from payload", 
        {
            data: userData,
        });

        if(!userData.email) throw new BadRequestError("Missing email from payload", 
        {
            data: userData,
        });
        if(!userData.payment) throw new BadRequestError("Missing payment from payload", 
        {
            data: userData,
        });
        if(!userData.sector) throw new BadRequestError("Missing sector from payload", 
        {
            data: userData,
        });
        if(!userData.contract) throw new BadRequestError("Missing contract from payload", 
        {
            data: userData,
        });

        return await this.userRepository.createUser(userData);
    }
    async updateUser(userID, userData)
    {
        if(!userID) throw new BadRequestError("Missing user identification from payload");

        if(!userData || Object.keys(userData).length === 0)
            throw new BadRequestError("Missing user data from payload",
            {
                data: userData,
            });

        const user = await this.userRepository.getUser(userID);

        if(!user) throw new NotFoundError("Can not found user with this user identification",
        {
            data: userID
        });

        return await this.userRepository.updateUser(userID, userData);
    }

    async deleteUser(userID)
    {
        if(!userID) throw new BadRequestError("Missing user identification from payload");

        const user = await this.userRepository.getUser(userID);

        if(!user) throw new NotFoundError("Can not found user with this user identification",
        {
            data: userID
        });

        await this.userRepository.deleteUser(userID);
        return { success: true };
    }
}

module.exports = UserService;